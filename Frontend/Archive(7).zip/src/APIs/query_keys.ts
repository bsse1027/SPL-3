export const QUERY_KEY = {
  ANALYTICS: ["analyticsKey"] as const,
};
