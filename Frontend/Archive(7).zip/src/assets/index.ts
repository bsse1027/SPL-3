import Logo from "./Logo_Google_Analytics.png";
import Run from "./play-button.png";

export const Assets = {
  Logo,
  Run,
};
